export default function localizeExtractLoader(this: import('webpack').loader.LoaderContext, content: string, map: any): void;
