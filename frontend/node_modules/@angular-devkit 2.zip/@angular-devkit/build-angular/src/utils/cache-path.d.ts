export declare function findCachePath(name: string): string;
