/// <amd-module name="@angular/compiler-cli/ngcc/src/locking/lock_file_with_child_process/unlocker" />
export {};
