#!/usr/bin/env node
/// <amd-module name="@angular/compiler-cli/ngcc/src/command_line_options" />
import { NgccOptions } from './ngcc_options';
export declare function parseCommandLineOptions(args: string[]): NgccOptions;
