#!/usr/bin/env node
/// <amd-module name="@angular/compiler-cli/ngcc/main-ngcc" />
export {};
