/// <amd-module name="@angular/compiler-cli/src/ngtsc/util/src/path" />
export declare function relativePathBetween(from: string, to: string): string | null;
export declare function normalizeSeparators(path: string): string;
