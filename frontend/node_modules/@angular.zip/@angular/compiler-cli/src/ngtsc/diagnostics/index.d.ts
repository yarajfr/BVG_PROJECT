/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/// <amd-module name="@angular/compiler-cli/src/ngtsc/diagnostics" />
export { FatalDiagnosticError, isFatalDiagnosticError, makeDiagnostic, makeRelatedInformation } from './src/error';
export { ErrorCode, ngErrorCode } from './src/error_code';
export { replaceTsWithNgInErrors } from './src/util';
