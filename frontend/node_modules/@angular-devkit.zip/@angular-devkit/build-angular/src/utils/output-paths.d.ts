import { I18nOptions } from './i18n-options';
export declare function ensureOutputPaths(baseOutputPath: string, i18n: I18nOptions): Map<string, string>;
